package dev.mrnofade.starstrappingutils.mixin;

import dev.mrnofade.starstrappingutils.StuBalTracker;
import net.minecraft.client.gui.hud.ChatHud;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ChatHud.class)
public class ChatHideMixin {

    @Inject(method = "addMessage(Lnet/minecraft/text/Text;)V", at = @At("HEAD"), cancellable = true)
    private void stuInterceptChat(Text message, CallbackInfo ci) {
        if (StuBalTracker.tryCapture(message.getString())) {
            ci.cancel();
        }
    }
}
